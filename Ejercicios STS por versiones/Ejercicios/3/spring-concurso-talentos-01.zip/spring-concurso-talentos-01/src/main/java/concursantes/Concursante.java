package concursantes;

public interface Concursante {

    public void ejecutar() throws EjecucionException;
}
