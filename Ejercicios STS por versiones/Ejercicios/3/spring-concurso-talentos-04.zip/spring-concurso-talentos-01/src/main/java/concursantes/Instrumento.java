package concursantes;

public interface Instrumento {
	void tocar();
}