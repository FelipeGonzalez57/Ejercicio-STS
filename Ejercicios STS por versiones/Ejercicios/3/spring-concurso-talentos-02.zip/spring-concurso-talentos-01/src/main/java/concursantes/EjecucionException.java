package concursantes;

class EjecucionException extends RuntimeException {
	public EjecucionException() {
	}

	public EjecucionException(String msg) {
		super(msg);
	}
}