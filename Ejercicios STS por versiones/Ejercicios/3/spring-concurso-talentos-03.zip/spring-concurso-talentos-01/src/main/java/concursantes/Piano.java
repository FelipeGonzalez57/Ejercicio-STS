package concursantes;

public class Piano implements Instrumento {

	public void tocar() {
		System.out.println("Clin clin clin clin...");
	}

}
