package concursantes;

public class Saxofon implements Instrumento{

	public void tocar() {
		System.out.println("Tuu tuu tuu tuu...");
	}

}
