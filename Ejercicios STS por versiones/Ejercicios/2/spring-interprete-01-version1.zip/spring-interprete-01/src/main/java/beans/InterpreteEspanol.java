package beans;

public class InterpreteEspanol {
	
	public void saludar() {
		System.out.println("Hola, mi nombre es ");
	}

	public void despedirse() {
		System.out.println("Hasta pronto...");
	}
	
}