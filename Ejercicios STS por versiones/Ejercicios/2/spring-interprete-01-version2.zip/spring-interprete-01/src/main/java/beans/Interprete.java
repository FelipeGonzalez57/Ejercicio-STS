package beans;

public interface Interprete {

	public void saludar();

	public void despedirse();
}
