package beans;

public class InterpreteEspanol implements Interprete {

	public void saludar(){
		System.out.println("Hola, mi nombre es ");
	}
	
	public void despedirse(){
		System.out.println("Hasta pronto...");
	}

}
