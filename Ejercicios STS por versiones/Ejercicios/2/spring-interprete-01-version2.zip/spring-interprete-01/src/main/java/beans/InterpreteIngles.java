package beans;

public class InterpreteIngles implements Interprete {

	public void saludar() {
		System.out.println("Hello, my name is ");
	}

	public void despedirse() {
		System.out.println("Bye...");
	}

}
