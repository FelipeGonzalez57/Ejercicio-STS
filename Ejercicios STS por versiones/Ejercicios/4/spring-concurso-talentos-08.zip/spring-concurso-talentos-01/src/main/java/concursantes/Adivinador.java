package concursantes;

public interface Adivinador {
	public void interceptarPensamientos(String pensamientos);

	public String getPensamientos();
}