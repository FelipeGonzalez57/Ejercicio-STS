package concursantes;

public interface Pensador {
	void pensarEnAlgo(String pensamientos);
}