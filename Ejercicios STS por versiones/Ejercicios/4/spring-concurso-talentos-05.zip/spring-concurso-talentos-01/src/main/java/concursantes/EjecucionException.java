package concursantes;

class EjecucionException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public EjecucionException() {
    }

    public EjecucionException(String msg) {
        super(msg);
    }
}
