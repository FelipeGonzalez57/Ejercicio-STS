package concursantes;

public interface Poema {
	void recitar();

}
